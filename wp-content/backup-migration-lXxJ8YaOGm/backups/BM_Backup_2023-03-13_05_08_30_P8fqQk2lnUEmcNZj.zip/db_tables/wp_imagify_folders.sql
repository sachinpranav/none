/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_imagify_folders`; */
/* PRE_TABLE_NAME: `1678684116_wp_imagify_folders`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678684116_wp_imagify_folders` ( `folder_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `path` varchar(191) NOT NULL DEFAULT '', `active` tinyint(1) unsigned NOT NULL DEFAULT 0, PRIMARY KEY (`folder_id`), UNIQUE KEY `path` (`path`), KEY `active` (`active`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
