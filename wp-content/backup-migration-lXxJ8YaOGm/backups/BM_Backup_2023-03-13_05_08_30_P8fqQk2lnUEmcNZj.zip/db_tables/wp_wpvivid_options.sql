/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpvivid_options`; */
/* PRE_TABLE_NAME: `1678684116_wp_wpvivid_options`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1678684116_wp_wpvivid_options` ( `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `option_name` varchar(191) NOT NULL DEFAULT '', `option_value` longtext NOT NULL, PRIMARY KEY (`option_id`), UNIQUE KEY `option_name` (`option_name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
